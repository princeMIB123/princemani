import React, { Component } from 'react'
import OrderService from '../services/OrderService';

class CreateOrderComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            id: this.props.match.params.id,
            noofProduct: '',
            createdBy: '',
            status: ''
        }
        this.changeFirstNameHandler = this.changeFirstNameHandler.bind(this);
        this.changeLastNameHandler = this.changeLastNameHandler.bind(this);
        this.saveOrUpdateEmployee = this.saveOrUpdateEmployee.bind(this);
    }

    // step 3
    componentDidMount(){

        // step 4
        if(this.state.id === '_add'){
            return
        }else{
            OrderService.getEmployeeById(this.state.id).then( (res) =>{
                let employee = res.data;
                this.setState({noofProduct: employee.noofProduct,
                    createdBy: employee.createdBy,
                    status : employee.status
                });
            });
        }        
    }



    saveOrUpdateEmployee = (e) => {
        e.preventDefault();
        let employee = {noofProduct: this.state.noofProduct, createdBy: this.state.createdBy, status:"APPROVED"};
        console.log('employee => ' + JSON.stringify(employee));

        // step 5
        if(this.state.id === '_add'){
            OrderService.createEmployee(employee).then(res =>{
                this.props.history.push('/orders');
            });
        }else{
            OrderService.updateEmployee(employee, this.state.id).then( res => {
                this.props.history.push('/orders');
            });
        }
    }


    rejectOrder = (e) => {
        e.preventDefault();
        let employee = {noofProduct: this.state.noofProduct, createdBy: this.state.createdBy, status:"Rejected"};
        console.log('employee => ' + JSON.stringify(employee));

        // step 5
        if(this.state.id === '_add'){
            OrderService.createEmployee(employee).then(res =>{
                this.props.history.push('/orders');
            });
        }else{
            OrderService.updateEmployee(employee, this.state.id).then( res => {
                this.props.history.push('/orders');
            });
        }
    }





    
    changeFirstNameHandler= (event) => {
        this.setState({noofProduct: event.target.value});
    }

    changeLastNameHandler= (event) => {
        this.setState({createdBy: event.target.value});
    }

    changeEmailHandler= (event) => {
        this.setState({status:event.target.value});
    }

    cancel(){
        this.props.history.push('/orders');
    }

    getTitle(){
        if(this.state.id === '_add'){
            return <h3 className="text-center">Orders</h3>
        }else{
            return <h3 className="text-center">Request to approve</h3>
        }
    }
    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                {
                                    this.getTitle()
                                }
                                <div className = "card-body">
                                    <form>
                                        <div className = "form-group">
                                            <label>No of Product</label>
                                            <input placeholder="No of Product" name="noofProduct" className="form-control" 
                                                value={this.state.noofProduct} onChange={this.changeFirstNameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label>Created by</label>
                                            <input placeholder="Last Name" name="createdBy" className="form-control" 
                                                value={this.state.createdBy} onChange={this.changeLastNameHandler}/>
                                        </div>
                                        <br></br>
                                        <br></br>
                                  

                                        <div>
                                            <h5>Please click confirm to approve the request</h5>
                                        </div>

        
    
                                       

                                        <button className="btn btn-success" onClick={this.saveOrUpdateEmployee}>Approve</button>
                                        <button className="btn btn-success" onClick={this.rejectOrder} style={{marginLeft: "10px"}}  >Reject</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
        )
    }
}

export default CreateOrderComponent
