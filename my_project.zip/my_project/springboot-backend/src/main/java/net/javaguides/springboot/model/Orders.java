package net.javaguides.springboot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "orders")
public class Orders{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	@Column(name = "id")
	private long id;
	
	@Column(name = "no_of_product")
	private String noofProduct;

	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "status")
	private String status;
	
	public Orders() {
		
	}
	
	public Orders(String noofProduct, String createdBy, String status) {
		super();
		this.noofProduct = noofProduct;
		this.createdBy = createdBy;
		this.status=status;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getnoofProduct() {
		return noofProduct;
	}
	public void setnoofProduct(String noofProduct) {
		this.noofProduct = noofProduct;
	}
	public String getcreatedBy() {
		return createdBy;
	}
	public void setcreatedBy(String createdBy) {
	    this.createdBy = createdBy;
	}
	public String getstatus() {
		return status;
	}
	public void setstatus(String status) {
		this.status = status;
	}
}
